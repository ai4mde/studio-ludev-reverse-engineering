from django.shortcuts import render

def homerender(request):
    context = {}
    return render(request, 'noauth_home_index.html', context)