from django.urls import path
from . import views

urlpatterns = [
    path("", views.homerender, name="noauth_home-homerender"),
]